//// Main.java
//package main;
//
//import java.util.Scanner;
//
//import database.DatabaseConnection;
//import database.DatabaseManager;
//import logIn.UserManager;
//
//public class Main {
//	public static void main(String[] args) {
//		Scanner scanner = new Scanner(System.in);
//
//		System.out.println("Enter database name:");
//		String dbName = scanner.nextLine();
//		String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
//
//		System.out.println("Enter database username:");
//		String dbUser = scanner.nextLine();
//		System.out.println("Enter database password:");
//		String dbPassword = scanner.nextLine();
//
//		DatabaseConnection dbConnection = new DatabaseConnection(dbUrl, dbUser, dbPassword);
//		if (dbConnection.connect()) {
//			DataBaseManager dbManager = new DatabaseManager(dbConnection.getConnection());
//			UserManager userManager = new UserManager(dbConnection.getConnection());
//
//			System.out.println("1 -> Login\n2 -> Sign Up");
//			int choice = scanner.nextInt();
//			scanner.nextLine();
//
//			switch (choice) {
//			case 1 -> {
//				System.out.println("Enter email:");
//				String email = scanner.nextLine();
//				System.out.println("Enter password:");
//				String password = scanner.nextLine();
//				userManager.checkUser(email, password);
//			}
//			case 2 -> {
//				System.out.println("Enter name:");
//				String name = scanner.nextLine();
//				System.out.println("Enter email:");
//				String email = scanner.nextLine();
//				System.out.println("Enter password:");
//				String password = scanner.nextLine();
//				userManager.createUser(name, email, password);
//			}
//			default -> System.out.println("Invalid choice.");
//			}
//
//			dbConnection.close();
//		}
//	}
//}
